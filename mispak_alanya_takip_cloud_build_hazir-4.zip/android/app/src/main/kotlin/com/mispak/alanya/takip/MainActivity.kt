package com.mispak.alanya.takip

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
