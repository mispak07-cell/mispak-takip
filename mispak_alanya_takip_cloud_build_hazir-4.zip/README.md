# MİSPAK ALANYA TAKİP

Bu sürümde 359 müşteri kaydı başlangıç verisi olarak uygulamaya eklendi.

İlk açılışta uygulama `assets/database/mispak_seed.db` dosyasını cihazdaki SQLite veritabanına kopyalar.
