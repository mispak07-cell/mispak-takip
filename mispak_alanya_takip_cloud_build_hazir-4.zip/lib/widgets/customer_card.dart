import 'package:flutter/material.dart';
import '../models/customer.dart';

class CustomerCard extends StatelessWidget {
  final Customer customer;
  final VoidCallback onTap;

  const CustomerCard({super.key, required this.customer, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: const Color(0xFF1E1E1E),
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: CircleAvatar(
          backgroundColor: Colors.teal.withOpacity(0.2),
          child: Text(customer.name.substring(0, 1).toUpperCase(), style: const TextStyle(color: Colors.teal, fontWeight: FontWeight.bold)),
        ),
        title: Text(customer.name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 4),
            Text(customer.phone, style: TextStyle(color: Colors.grey[500], fontSize: 13)),
            if (customer.neighborhood != null) Text(customer.neighborhood!, style: TextStyle(color: Colors.grey[600], fontSize: 12)),
          ],
        ),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            const Icon(Icons.chevron_right, color: Colors.grey),
            if (customer.debt > 0)
              Container(
                margin: const EdgeInsets.only(top: 4),
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(color: Colors.red.withOpacity(0.2), borderRadius: BorderRadius.circular(10)),
                child: Text('${customer.debt.toStringAsFixed(0)}₺', style: const TextStyle(color: Colors.red, fontSize: 11, fontWeight: FontWeight.bold)),
              ),
          ],
        ),
        onTap: onTap,
      ),
    );
  }
}
