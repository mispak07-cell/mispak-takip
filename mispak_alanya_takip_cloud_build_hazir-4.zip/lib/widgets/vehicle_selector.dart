import 'package:flutter/material.dart';

class VehicleSelector extends StatefulWidget {
  const VehicleSelector({super.key});

  @override
  State<VehicleSelector> createState() => _VehicleSelectorState();
}

class _VehicleSelectorState extends State<VehicleSelector> {
  final List<String> _vehicles = ['Araç 1', 'Araç 2', 'Araç 3'];
  final List<String> _selectedVehicles = ['Araç 1'];

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {},
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(color: const Color(0xFF1E1E1E), borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.teal.withOpacity(0.3))),
        child: Row(
          children: [
            const Icon(Icons.local_shipping, color: Colors.teal),
            const SizedBox(width: 12),
            Expanded(child: Text('${_selectedVehicles.length} Araç Seçili', style: const TextStyle(color: Colors.white))),
            const Icon(Icons.arrow_drop_down, color: Colors.grey),
          ],
        ),
      ),
    );
  }
}
