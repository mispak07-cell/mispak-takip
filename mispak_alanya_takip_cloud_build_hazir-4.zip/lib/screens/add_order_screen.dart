import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/customer.dart';
import '../models/order.dart';
import '../services/database_service.dart';

class AddOrderScreen extends StatefulWidget {
  final Customer? customer;
  const AddOrderScreen({super.key, this.customer});

  @override
  State<AddOrderScreen> createState() => _AddOrderScreenState();
}

class _AddOrderScreenState extends State<AddOrderScreen> {
  final DatabaseService _db = DatabaseService();
  Customer? _selectedCustomer;
  ProductType _selectedProduct = ProductType.carpet;
  final _quantityController = TextEditingController(text: '1');
  final _unitPriceController = TextEditingController(text: '50');
  final _notesController = TextEditingController();
  OrderStatus _status = OrderStatus.toBePickedUp;
  bool _isPaid = false;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _selectedCustomer = widget.customer;
  }

  double get _totalPrice {
    final quantity = int.tryParse(_quantityController.text) ?? 1;
    final unitPrice = double.tryParse(_unitPriceController.text) ?? 0;
    return quantity * unitPrice;
  }

  Future<void> _saveOrder() async {
    if (_selectedCustomer == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Lütfen müşteri seçin')));
      return;
    }

    setState(() => _isLoading = true);

    try {
      final receiptNumber = await _db.generateReceiptNumber();
      final order = Order(
        customerId: _selectedCustomer!.id!,
        receiptNumber: receiptNumber,
        productType: _selectedProduct,
        quantity: int.parse(_quantityController.text),
        unitPrice: double.parse(_unitPriceController.text),
        totalPrice: _totalPrice,
        status: _status,
        isPaid: _isPaid,
      );

      await _db.insertOrder(order);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Sipariş oluşturuldu: $receiptNumber'), backgroundColor: Colors.green));
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Hata: $e'), backgroundColor: Colors.red));
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(backgroundColor: const Color(0xFF1E1E1E), elevation: 0, title: const Text('Yeni Sipariş', style: TextStyle(color: Colors.white))),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildCustomerSelector(),
            const SizedBox(height: 24),
            _buildProductSelector(),
            const SizedBox(height: 24),
            _buildDetailsSection(),
            const SizedBox(height: 24),
            _buildTotalSection(),
            const SizedBox(height: 32),
            SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _saveOrder,
                style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                child: _isLoading ? const CircularProgressIndicator(color: Colors.white) : const Text('SİPARİŞ KAYDET', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCustomerSelector() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: const Color(0xFF1E1E1E), borderRadius: BorderRadius.circular(12), border: Border.all(color: _selectedCustomer != null ? Colors.teal : Colors.grey[700]!)),
      child: Row(children: [
        const Icon(Icons.person, color: Colors.teal),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Müşteri', style: TextStyle(fontSize: 12, color: Colors.grey[500])),
          Text(_selectedCustomer?.name ?? 'Müşteri Seçildi', style: TextStyle(fontSize: 16, color: _selectedCustomer != null ? Colors.white : Colors.grey)),
        ])),
      ]),
    );
  }

  Widget _buildProductSelector() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Ürün Türü', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.grey[300])),
      const SizedBox(height: 12),
      Wrap(
        spacing: 8,
        runSpacing: 8,
        children: ProductType.values.map((product) {
          final isSelected = _selectedProduct == product;
          return ChoiceChip(
            label: Text(product.displayName),
            selected: isSelected,
            onSelected: (selected) { if (selected) setState(() => _selectedProduct = product); },
            backgroundColor: const Color(0xFF1E1E1E),
            selectedColor: product.color.withOpacity(0.3),
            labelStyle: TextStyle(color: isSelected ? product.color : Colors.grey[400]),
            side: BorderSide(color: isSelected ? product.color : Colors.grey[700]!),
          );
        }).toList(),
      ),
    ]);
  }

  Widget _buildDetailsSection() {
    return Row(children: [
      Expanded(child: _buildTextField(controller: _quantityController, label: 'Adet', icon: Icons.format_list_numbered, keyboardType: TextInputType.number, onChanged: (_) => setState(() {}))),
      const SizedBox(width: 16),
      Expanded(child: _buildTextField(controller: _unitPriceController, label: 'Birim Fiyat (₺)', icon: Icons.attach_money, keyboardType: TextInputType.number, onChanged: (_) => setState(() {}))),
    ]);
  }

  Widget _buildTotalSection() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(gradient: LinearGradient(colors: [Colors.teal.withOpacity(0.3), Colors.orange.withOpacity(0.3)]), borderRadius: BorderRadius.circular(16)),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text('Toplam Tutar', style: TextStyle(fontSize: 16, color: Colors.grey[300])),
        Text(NumberFormat.currency(locale: 'tr_TR', symbol: '₺').format(_totalPrice), style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.white)),
      ]),
    );
  }

  Widget _buildTextField({required TextEditingController controller, required String label, required IconData icon, TextInputType? keyboardType, void Function(String)? onChanged}) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      onChanged: onChanged,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(labelText: label, labelStyle: TextStyle(color: Colors.grey[500]), prefixIcon: Icon(icon, color: Colors.teal), filled: true, fillColor: const Color(0xFF1E1E1E), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none)),
    );
  }
}
