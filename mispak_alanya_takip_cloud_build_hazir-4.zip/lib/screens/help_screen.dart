import 'package:flutter/material.dart';
import '../services/database_service.dart';
import '../services/whatsapp_service.dart';
import '../services/sms_service.dart';
import '../models/announcement.dart';

class HelpScreen extends StatefulWidget {
  const HelpScreen({super.key});

  @override
  State<HelpScreen> createState() => _HelpScreenState();
}

class _HelpScreenState extends State<HelpScreen> {
  final DatabaseService _db = DatabaseService();
  List<Announcement> _announcements = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadAnnouncements();
  }

  Future<void> _loadAnnouncements() async {
    final announcements = await _db.getAllAnnouncements();
    setState(() { _announcements = announcements; _isLoading = false; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(backgroundColor: const Color(0xFF1E1E1E), elevation: 0, title: const Text('Duyuru / Yardım', style: TextStyle(color: Colors.white))),
      body: Column(children: [
        _buildContactButtons(),
        Expanded(child: _isLoading ? const Center(child: CircularProgressIndicator(color: Colors.teal)) : _buildAnnouncementsList()),
      ]),
    );
  }

  Widget _buildContactButtons() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Row(children: [
        Expanded(child: ElevatedButton.icon(onPressed: () => WhatsAppService.openWhatsApp('905551234567', message: 'Destek talebi'), icon: const Icon(Icons.chat), label: const Text('WhatsApp'), style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF25D366), foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 16)))),
        const SizedBox(width: 12),
        Expanded(child: ElevatedButton.icon(onPressed: () => SMSService.makePhoneCall('905551234567'), icon: const Icon(Icons.call), label: const Text('Hemen Ara'), style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 16)))),
      ]),
    );
  }

  Widget _buildAnnouncementsList() {
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: _announcements.length,
      itemBuilder: (context, index) {
        final announcement = _announcements[index];
        return Card(
          color: const Color(0xFF1E1E1E),
          margin: const EdgeInsets.only(bottom: 12),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: announcement.isImportant ? const BorderSide(color: Colors.orange, width: 1) : BorderSide.none),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                if (announcement.isImportant)
                  Container(margin: const EdgeInsets.only(right: 8), padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: Colors.orange.withOpacity(0.2), borderRadius: BorderRadius.circular(8)), child: const Text('ÖNEMLİ', style: TextStyle(color: Colors.orange, fontSize: 10, fontWeight: FontWeight.bold))),
                Expanded(child: Text(announcement.title, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold))),
              ]),
              const SizedBox(height: 12),
              Text(announcement.description, style: TextStyle(color: Colors.grey[400], fontSize: 14, height: 1.5)),
            ]),
          ),
        );
      },
    );
  }
}
