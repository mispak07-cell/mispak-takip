import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/report_service.dart';
import '../services/database_service.dart';
import '../models/order.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  final ReportService _reportService = ReportService();
  final DatabaseService _db = DatabaseService();
  Map<String, dynamic>? _dailyReport;
  Map<String, int>? _statusDistribution;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadReports();
  }

  Future<void> _loadReports() async {
    final now = DateTime.now();
    final dailyReport = await _reportService.generateDailyReport(now);
    final statusDist = await _reportService.getOrderDistributionByStatus();

    setState(() {
      _dailyReport = dailyReport;
      _statusDistribution = statusDist;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(backgroundColor: const Color(0xFF1E1E1E), elevation: 0, title: const Text('Raporlar', style: TextStyle(color: Colors.white))),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: Colors.teal))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                _buildDailySummary(),
                const SizedBox(height: 24),
                _buildStatusDistribution(),
              ]),
            ),
    );
  }

  Widget _buildDailySummary() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(gradient: LinearGradient(colors: [Colors.teal.withOpacity(0.3), Colors.purple.withOpacity(0.3)]), borderRadius: BorderRadius.circular(20)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Bugünün Özeti', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white)),
        const SizedBox(height: 20),
        Row(children: [
          Expanded(child: _buildReportItem('Gelir', NumberFormat.currency(locale: 'tr_TR', symbol: '₺').format(_dailyReport?['income'] ?? 0), Colors.teal, Icons.arrow_upward)),
          Expanded(child: _buildReportItem('Gider', NumberFormat.currency(locale: 'tr_TR', symbol: '₺').format(_dailyReport?['expense'] ?? 0), Colors.red, Icons.arrow_downward)),
        ]),
      ]),
    );
  }

  Widget _buildReportItem(String label, String value, Color color, IconData icon) {
    return Container(
      margin: const EdgeInsets.all(4),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: const Color(0xFF1E1E1E), borderRadius: BorderRadius.circular(12)),
      child: Column(children: [Icon(icon, color: color), const SizedBox(height: 8), Text(value, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color)), Text(label, style: TextStyle(fontSize: 12, color: Colors.grey[400]))]),
    );
  }

  Widget _buildStatusDistribution() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: const Color(0xFF1E1E1E), borderRadius: BorderRadius.circular(20)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Sipariş Durum Dağılımı', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
        const SizedBox(height: 16),
        ...?_statusDistribution?.entries.map((entry) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text(entry.key, style: const TextStyle(color: Colors.white)),
              Text(entry.value.toString(), style: const TextStyle(color: Colors.teal, fontWeight: FontWeight.bold)),
            ]),
          );
        }).toList(),
      ]),
    );
  }
}
