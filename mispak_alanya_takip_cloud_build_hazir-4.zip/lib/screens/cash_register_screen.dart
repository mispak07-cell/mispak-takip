import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/transaction.dart';
import '../services/database_service.dart';

class CashRegisterScreen extends StatefulWidget {
  const CashRegisterScreen({super.key});

  @override
  State<CashRegisterScreen> createState() => _CashRegisterScreenState();
}

class _CashRegisterScreenState extends State<CashRegisterScreen> {
  final DatabaseService _db = DatabaseService();
  List<Transaction> _transactions = [];
  Map<String, double> _dailyTotals = {};
  DateTime _selectedDate = DateTime.now();
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final transactions = await _db.getTransactionsByDate(_selectedDate);
    final totals = await _db.getDailyTotals(_selectedDate);
    setState(() {
      _transactions = transactions;
      _dailyTotals = totals;
      _isLoading = false;
    });
  }

  void _showAddTransactionDialog(TransactionType type) {
    final amountController = TextEditingController();
    final descriptionController = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF1E1E1E),
      builder: (context) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom, left: 16, right: 16, top: 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(type == TransactionType.income ? 'Gelir Ekle' : 'Gider Ekle', style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            TextField(
              controller: amountController,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(labelText: 'Tutar (₺)', labelStyle: TextStyle(color: Colors.grey[500]), prefixIcon: const Icon(Icons.attach_money, color: Colors.teal), filled: true, fillColor: const Color(0xFF2C2C2C), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none)),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: descriptionController,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(labelText: 'Açıklama', labelStyle: TextStyle(color: Colors.grey[500]), prefixIcon: const Icon(Icons.description, color: Colors.teal), filled: true, fillColor: const Color(0xFF2C2C2C), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none)),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton(
                onPressed: () async {
                  final transaction = Transaction(
                    type: type,
                    amount: double.parse(amountController.text),
                    description: descriptionController.text,
                    date: _selectedDate,
                  );
                  await _db.insertTransaction(transaction);
                  if (mounted) {
                    Navigator.pop(context);
                    _loadData();
                  }
                },
                style: ElevatedButton.styleFrom(backgroundColor: type == TransactionType.income ? Colors.green : Colors.red, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                child: Text(type == TransactionType.income ? 'GELİR KAYDET' : 'GİDER KAYDET', style: const TextStyle(fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(backgroundColor: const Color(0xFF1E1E1E), elevation: 0, title: const Text('Kasa', style: TextStyle(color: Colors.white))),
      body: Column(
        children: [
          _buildSummaryCard(),
          const SizedBox(height: 16),
          _buildActionButtons(),
          const SizedBox(height: 16),
          Expanded(child: _isLoading ? const Center(child: CircularProgressIndicator(color: Colors.teal)) : _buildTransactionList()),
        ],
      ),
    );
  }

  Widget _buildSummaryCard() {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(gradient: LinearGradient(colors: [Colors.teal.withOpacity(0.3), Colors.orange.withOpacity(0.3)]), borderRadius: BorderRadius.circular(20)),
      child: Column(
        children: [
          Text(DateFormat('dd MMMM yyyy', 'tr_TR').format(_selectedDate), style: TextStyle(fontSize: 16, color: Colors.grey[300])),
          const SizedBox(height: 20),
          Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
            _buildSummaryItem('Gelir', NumberFormat.currency(locale: 'tr_TR', symbol: '₺').format(_dailyTotals['income'] ?? 0), Colors.green, Icons.arrow_upward),
            _buildSummaryItem('Gider', NumberFormat.currency(locale: 'tr_TR', symbol: '₺').format(_dailyTotals['expense'] ?? 0), Colors.red, Icons.arrow_downward),
            _buildSummaryItem('Bakiye', NumberFormat.currency(locale: 'tr_TR', symbol: '₺').format(_dailyTotals['balance'] ?? 0), (_dailyTotals['balance'] ?? 0) >= 0 ? Colors.teal : Colors.orange, Icons.account_balance_wallet),
          ]),
        ],
      ),
    );
  }

  Widget _buildSummaryItem(String label, String value, Color color, IconData icon) {
    return Column(children: [
      Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: color.withOpacity(0.2), shape: BoxShape.circle), child: Icon(icon, color: color)),
      const SizedBox(height: 8),
      Text(value, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: color)),
      Text(label, style: TextStyle(fontSize: 12, color: Colors.grey[400])),
    ]);
  }

  Widget _buildActionButtons() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(children: [
        Expanded(child: ElevatedButton.icon(onPressed: () => _showAddTransactionDialog(TransactionType.income), icon: const Icon(Icons.add), label: const Text('Gelir'), style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 16)))),
        const SizedBox(width: 16),
        Expanded(child: ElevatedButton.icon(onPressed: () => _showAddTransactionDialog(TransactionType.expense), icon: const Icon(Icons.remove), label: const Text('Gider'), style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 16)))),
      ]),
    );
  }

  Widget _buildTransactionList() {
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: _transactions.length,
      itemBuilder: (context, index) {
        final transaction = _transactions[index];
        final isIncome = transaction.type == TransactionType.income;
        return Card(
          color: const Color(0xFF1E1E1E),
          margin: const EdgeInsets.only(bottom: 8),
          child: ListTile(
            leading: Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: isIncome ? Colors.green.withOpacity(0.2) : Colors.red.withOpacity(0.2), shape: BoxShape.circle), child: Icon(isIncome ? Icons.arrow_upward : Icons.arrow_downward, color: isIncome ? Colors.green : Colors.red)),
            title: Text(transaction.description, style: const TextStyle(color: Colors.white)),
            trailing: Text((isIncome ? '+' : '-') + ' ' + NumberFormat.currency(locale: 'tr_TR', symbol: '₺').format(transaction.amount), style: TextStyle(color: isIncome ? Colors.green : Colors.red, fontWeight: FontWeight.bold, fontSize: 16)),
          ),
        );
      },
    );
  }
}
