import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/customer.dart';
import '../services/database_service.dart';
import '../services/whatsapp_service.dart';
import '../services/sms_service.dart';
import 'add_order_screen.dart';

class CustomerDetailScreen extends StatefulWidget {
  final Customer customer;
  const CustomerDetailScreen({super.key, required this.customer});

  @override
  State<CustomerDetailScreen> createState() => _CustomerDetailScreenState();
}

class _CustomerDetailScreenState extends State<CustomerDetailScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1E1E1E),
        elevation: 0,
        title: Text(widget.customer.name, style: const TextStyle(color: Colors.white)),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Colors.teal,
          labelColor: Colors.teal,
          unselectedLabelColor: Colors.grey,
          tabs: const [Tab(text: 'Detay'), Tab(text: 'Sipariş'), Tab(text: 'Mesaj'), Tab(text: 'Tahsilat')],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildDetailTab(),
          _buildOrdersTab(),
          _buildMessageTab(),
          _buildCollectionTab(),
        ],
      ),
    );
  }

  Widget _buildDetailTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _buildInfoCard(),
          const SizedBox(height: 16),
          _buildContactButtons(),
        ],
      ),
    );
  }

  Widget _buildInfoCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: const Color(0xFF1E1E1E), borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.teal.withOpacity(0.3))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildInfoRow('Müşteri No', widget.customer.customerNumber),
          const Divider(height: 24, color: Color(0xFF2C2C2C)),
          _buildInfoRow('Telefon', widget.customer.phone),
          if (widget.customer.phone2 != null) ...[const SizedBox(height: 12), _buildInfoRow('Telefon 2', widget.customer.phone2!)],
          const Divider(height: 24, color: Color(0xFF2C2C2C)),
          _buildInfoRow('Adres', widget.customer.address),
          const Divider(height: 24, color: Color(0xFF2C2C2C)),
          _buildInfoRow('Borç', NumberFormat.currency(locale: 'tr_TR', symbol: '₺').format(widget.customer.debt)),
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: TextStyle(fontSize: 12, color: Colors.grey[500])),
        const SizedBox(height: 4),
        Text(value, style: const TextStyle(fontSize: 16, color: Colors.white, fontWeight: FontWeight.w500)),
      ])),
    ]);
  }

  Widget _buildContactButtons() {
    return Row(children: [
      Expanded(child: _buildContactButton(icon: Icons.message, label: 'SMS', color: Colors.orange, onTap: () => SMSService.sendSMS(widget.customer.phone))),
      const SizedBox(width: 12),
      Expanded(child: _buildContactButton(icon: Icons.call, label: 'Ara', color: Colors.green, onTap: () => SMSService.makePhoneCall(widget.customer.phone))),
      const SizedBox(width: 12),
      Expanded(child: _buildContactButton(icon: Icons.chat, label: 'WhatsApp', color: const Color(0xFF25D366), onTap: () => WhatsAppService.openWhatsApp(widget.customer.phone))),
    ]);
  }

  Widget _buildContactButton({required IconData icon, required String label, required Color color, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(color: color.withOpacity(0.2), borderRadius: BorderRadius.circular(12), border: Border.all(color: color.withOpacity(0.5))),
        child: Column(children: [Icon(icon, color: color, size: 28), const SizedBox(height: 8), Text(label, style: TextStyle(color: color, fontWeight: FontWeight.bold))]),
      ),
    );
  }

  Widget _buildOrdersTab() {
    return Center(child: ElevatedButton.icon(
      onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AddOrderScreen(customer: widget.customer))),
      icon: const Icon(Icons.add),
      label: const Text('Sipariş Ekle'),
      style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),
    ));
  }

  Widget _buildMessageTab() {
    final templates = ['Halılarınız yıkamaya alınmıştır', 'Halılarınız hazırdır', 'Yarın teslimat yapılacaktır', 'Ödemeniz bulunmaktadır'];
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: templates.length,
      itemBuilder: (context, index) {
        return Card(
          color: const Color(0xFF1E1E1E),
          child: ListTile(
            title: Text(templates[index], style: const TextStyle(color: Colors.white)),
            trailing: IconButton(icon: const Icon(Icons.chat, color: Color(0xFF25D366)), onPressed: () => WhatsAppService.sendTemplateMessage(widget.customer, index + 1)),
          ),
        );
      },
    );
  }

  Widget _buildCollectionTab() {
    return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Text('Toplam Borç', style: TextStyle(fontSize: 18, color: Colors.grey[500])),
      const SizedBox(height: 8),
      Text(NumberFormat.currency(locale: 'tr_TR', symbol: '₺').format(widget.customer.debt), style: const TextStyle(fontSize: 36, fontWeight: FontWeight.bold, color: Colors.red)),
    ]));
  }
}
