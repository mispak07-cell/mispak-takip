import 'package:flutter/material.dart';
import '../models/customer.dart';
import '../services/database_service.dart';

class AddCustomerScreen extends StatefulWidget {
  const AddCustomerScreen({super.key});

  @override
  State<AddCustomerScreen> createState() => _AddCustomerScreenState();
}

class _AddCustomerScreenState extends State<AddCustomerScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _phone2Controller = TextEditingController();
  final _addressController = TextEditingController();
  final _neighborhoodController = TextEditingController();
  final DatabaseService _db = DatabaseService();
  bool _isLoading = false;

  Future<void> _saveCustomer() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isLoading = true);

    try {
      final customerNumber = await _db.generateCustomerNumber();
      final customer = Customer(
        customerNumber: customerNumber,
        name: _nameController.text.trim(),
        phone: _phoneController.text.trim(),
        phone2: _phone2Controller.text.trim().isEmpty ? null : _phone2Controller.text.trim(),
        address: _addressController.text.trim(),
        neighborhood: _neighborhoodController.text.trim().isEmpty ? null : _neighborhoodController.text.trim(),
      );

      await _db.insertCustomer(customer);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Müşteri başarıyla eklendi'), backgroundColor: Colors.green));
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Hata: $e'), backgroundColor: Colors.red));
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(backgroundColor: const Color(0xFF1E1E1E), elevation: 0, title: const Text('Yeni Müşteri', style: TextStyle(color: Colors.white))),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              _buildTextField(controller: _nameController, label: 'Müşteri Adı *', icon: Icons.person, validator: (value) => value?.isEmpty ?? true ? 'Ad giriniz' : null),
              const SizedBox(height: 16),
              _buildTextField(controller: _phoneController, label: 'Telefon *', icon: Icons.phone, keyboardType: TextInputType.phone, validator: (value) => value?.isEmpty ?? true ? 'Telefon giriniz' : null),
              const SizedBox(height: 16),
              _buildTextField(controller: _phone2Controller, label: 'Telefon 2 (Opsiyonel)', icon: Icons.phone_android, keyboardType: TextInputType.phone),
              const SizedBox(height: 16),
              _buildTextField(controller: _addressController, label: 'Adres *', icon: Icons.location_on, maxLines: 3, validator: (value) => value?.isEmpty ?? true ? 'Adres giriniz' : null),
              const SizedBox(height: 16),
              _buildTextField(controller: _neighborhoodController, label: 'Mahalle (Opsiyonel)', icon: Icons.map),
              const SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _saveCustomer,
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                  child: _isLoading ? const CircularProgressIndicator(color: Colors.white) : const Text('MÜŞTERİ KAYDET', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField({required TextEditingController controller, required String label, required IconData icon, TextInputType? keyboardType, int maxLines = 1, String? Function(String?)? validator}) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      maxLines: maxLines,
      validator: validator,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(color: Colors.grey[500]),
        prefixIcon: Icon(icon, color: Colors.teal),
        filled: true,
        fillColor: const Color(0xFF1E1E1E),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.grey[800]!)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Colors.teal)),
      ),
    );
  }
}
