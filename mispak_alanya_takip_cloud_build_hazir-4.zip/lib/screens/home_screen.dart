import 'package:flutter/material.dart';
import '../services/database_service.dart';
import '../widgets/status_card.dart';
import '../widgets/action_button.dart';
import '../widgets/custom_bottom_nav.dart';
import '../widgets/vehicle_selector.dart';
import 'customers_screen.dart';
import 'management_screen.dart';
import 'help_screen.dart';
import 'add_order_screen.dart';
import 'cash_register_screen.dart';
import 'reports_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;
  final DatabaseService _db = DatabaseService();
  Map<String, dynamic> _stats = {};
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  Future<void> _loadStats() async {
    final stats = await _db.getDashboardStats();
    setState(() {
      _stats = stats;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final screens = [
      _buildHomePage(),
      const CustomersScreen(),
      const ManagementScreen(),
      const HelpScreen(),
    ];

    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      body: screens[_currentIndex],
      bottomNavigationBar: CustomBottomNav(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
      ),
    );
  }

  Widget _buildHomePage() {
    return SafeArea(
      child: RefreshIndicator(
        onRefresh: _loadStats,
        color: Colors.teal,
        backgroundColor: const Color(0xFF1E1E1E),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHeader(),
              const SizedBox(height: 20),
              const VehicleSelector(),
              const SizedBox(height: 24),
              _buildStatusCards(),
              const SizedBox(height: 24),
              _buildActionButtons(),
              const SizedBox(height: 24),
              _buildShortcuts(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('MİSPAK ALANYA', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white)),
            Text('Hoş Geldiniz', style: TextStyle(fontSize: 14, color: Colors.grey[400])),
          ],
        ),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: Colors.teal.withOpacity(0.2), borderRadius: BorderRadius.circular(12)),
          child: const Icon(Icons.notifications_outlined, color: Colors.teal),
        ),
      ],
    );
  }

  Widget _buildStatusCards() {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator(color: Colors.teal));
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Servis Durumu', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.grey[300])),
        const SizedBox(height: 12),
        GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 2,
          childAspectRatio: 1.5,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          children: [
            StatusCard(title: 'Teslim Alınacak', count: _stats['toBePickedUp'] ?? 0, color: Colors.orange, icon: Icons.download, onTap: () {}),
            StatusCard(title: 'Yıkamada', count: _stats['washing'] ?? 0, color: Colors.blue, icon: Icons.water_drop, onTap: () {}),
            StatusCard(title: 'Hazır', count: _stats['ready'] ?? 0, color: Colors.green, icon: Icons.check_circle, onTap: () {}),
            StatusCard(title: 'Teslim Edilecek', count: _stats['toBeDelivered'] ?? 0, color: Colors.purple, icon: Icons.delivery_dining, onTap: () {}),
          ],
        ),
      ],
    );
  }

  Widget _buildActionButtons() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Hızlı İşlemler', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.grey[300])),
        const SizedBox(height: 12),
        GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 2,
          childAspectRatio: 2.5,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          children: [
            ActionButton(title: 'Sipariş Ekle', icon: Icons.add_circle, color: Colors.teal, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AddOrderScreen()))),
            ActionButton(title: 'Gün Özeti', icon: Icons.summarize, color: Colors.orange, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ReportsScreen()))),
            ActionButton(title: 'Sipariş Ara', icon: Icons.search, color: Colors.purple, onTap: () {}),
            ActionButton(title: 'Kasa İşlemi', icon: Icons.account_balance_wallet, color: Colors.green, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CashRegisterScreen()))),
          ],
        ),
      ],
    );
  }

  Widget _buildShortcuts() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Kısayollar', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.grey[300])),
        const SizedBox(height: 12),
        Container(
          decoration: BoxDecoration(color: const Color(0xFF1E1E1E), borderRadius: BorderRadius.circular(16)),
          child: Column(
            children: [
              _buildShortcutTile(icon: Icons.call, title: 'Çağrı Geçmişi', color: Colors.blue, onTap: () {}),
              const Divider(height: 1, color: Color(0xFF2C2C2C)),
              _buildShortcutTile(icon: Icons.hourglass_empty, title: 'Bekleme Odası', color: Colors.orange, onTap: () {}),
              const Divider(height: 1, color: Color(0xFF2C2C2C)),
              _buildShortcutTile(icon: Icons.contacts, title: 'Rehberden Aktar', color: Colors.green, onTap: () {}),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildShortcutTile({required IconData icon, required String title, required Color color, required VoidCallback onTap}) {
    return ListTile(
      leading: Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: color.withOpacity(0.2), borderRadius: BorderRadius.circular(8)), child: Icon(icon, color: color)),
      title: Text(title, style: const TextStyle(color: Colors.white)),
      trailing: const Icon(Icons.chevron_right, color: Colors.grey),
      onTap: onTap,
    );
  }
}
