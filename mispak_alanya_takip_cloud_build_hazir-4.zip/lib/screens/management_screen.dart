import 'package:flutter/material.dart';
import '../services/database_service.dart';
import '../models/app_settings.dart';

class ManagementScreen extends StatefulWidget {
  const ManagementScreen({super.key});

  @override
  State<ManagementScreen> createState() => _ManagementScreenState();
}

class _ManagementScreenState extends State<ManagementScreen> {
  final DatabaseService _db = DatabaseService();
  AppSettings? _settings;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final settings = await _db.getSettings();
    setState(() { _settings = settings; _isLoading = false; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(backgroundColor: const Color(0xFF1E1E1E), elevation: 0, title: const Text('Yönetim', style: TextStyle(color: Colors.white))),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: Colors.teal))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(children: [
                _buildManagementGrid(),
                const SizedBox(height: 24),
                _buildInfoSection(),
              ]),
            ),
    );
  }

  Widget _buildManagementGrid() {
    final items = [
      {'icon': Icons.business, 'title': 'Firma Ayarları', 'color': Colors.blue},
      {'icon': Icons.label, 'title': 'Tanımlamalar', 'color': Colors.orange},
      {'icon': Icons.money_off, 'title': 'Veresiyeler', 'color': Colors.red},
      {'icon': Icons.devices, 'title': 'Yetkili Cihazlar', 'color': Colors.purple},
      {'icon': Icons.bar_chart, 'title': 'Raporlar', 'color': Colors.green},
      {'icon': Icons.account_balance, 'title': 'Kasa', 'color': Colors.teal},
      {'icon': Icons.sms, 'title': 'SMS Ayarları', 'color': Colors.amber},
      {'icon': Icons.person, 'title': 'Hesap Ayarları', 'color': Colors.indigo},
      {'icon': Icons.local_shipping, 'title': 'Şoför Takibi', 'color': Colors.cyan},
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, childAspectRatio: 0.8, crossAxisSpacing: 12, mainAxisSpacing: 12),
      itemCount: items.length,
      itemBuilder: (context, index) {
        final item = items[index];
        return Container(
          decoration: BoxDecoration(color: const Color(0xFF1E1E1E), borderRadius: BorderRadius.circular(16)),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: (item['color'] as Color).withOpacity(0.2), shape: BoxShape.circle), child: Icon(item['icon'] as IconData, color: item['color'] as Color, size: 32)),
            const SizedBox(height: 12),
            Text(item['title'] as String, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w500)),
          ]),
        );
      },
    );
  }

  Widget _buildInfoSection() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: const Color(0xFF1E1E1E), borderRadius: BorderRadius.circular(20)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Uygulama Bilgileri', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
        const SizedBox(height: 16),
        _buildInfoTile('Kalan SMS Hakkı', '${_settings?.smsBalance ?? 0}', Icons.sms, Colors.green),
        const Divider(height: 24, color: Color(0xFF2C2C2C)),
        _buildInfoTile('Versiyon', '1.0.0', Icons.info, Colors.blue),
      ]),
    );
  }

  Widget _buildInfoTile(String label, String value, IconData icon, Color color) {
    return Row(children: [
      Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: color.withOpacity(0.2), borderRadius: BorderRadius.circular(10)), child: Icon(icon, color: color, size: 20)),
      const SizedBox(width: 16),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: TextStyle(fontSize: 12, color: Colors.grey[500])),
        const SizedBox(height: 4),
        Text(value, style: const TextStyle(fontSize: 16, color: Colors.white, fontWeight: FontWeight.w500)),
      ])),
    ]);
  }
}
