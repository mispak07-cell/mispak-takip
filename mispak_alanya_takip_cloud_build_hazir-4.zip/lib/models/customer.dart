class Customer {
  final int? id;
  final String customerNumber;
  final String name;
  final String phone;
  final String? phone2;
  final String address;
  final String? neighborhood;
  final double debt;
  final String? notes;
  final DateTime createdAt;
  final DateTime updatedAt;

  Customer({
    this.id,
    required this.customerNumber,
    required this.name,
    required this.phone,
    this.phone2,
    required this.address,
    this.neighborhood,
    this.debt = 0.0,
    this.notes,
    DateTime? createdAt,
    DateTime? updatedAt,
  })  : createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'customer_number': customerNumber,
      'name': name,
      'phone': phone,
      'phone2': phone2,
      'address': address,
      'neighborhood': neighborhood,
      'debt': debt,
      'notes': notes,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  factory Customer.fromMap(Map<String, dynamic> map) {
    return Customer(
      id: map['id'] as int?,
      customerNumber: map['customer_number'] as String,
      name: map['name'] as String,
      phone: map['phone'] as String,
      phone2: map['phone2'] as String?,
      address: map['address'] as String,
      neighborhood: map['neighborhood'] as String?,
      debt: (map['debt'] as num).toDouble(),
      notes: map['notes'] as String?,
      createdAt: DateTime.parse(map['created_at'] as String),
      updatedAt: DateTime.parse(map['updated_at'] as String),
    );
  }

  Customer copyWith({
    int? id,
    String? customerNumber,
    String? name,
    String? phone,
    String? phone2,
    String? address,
    String? neighborhood,
    double? debt,
    String? notes,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return Customer(
      id: id ?? this.id,
      customerNumber: customerNumber ?? this.customerNumber,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      phone2: phone2 ?? this.phone2,
      address: address ?? this.address,
      neighborhood: neighborhood ?? this.neighborhood,
      debt: debt ?? this.debt,
      notes: notes ?? this.notes,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}
