import 'package:flutter/material.dart';

enum TransactionType {
  income,
  expense
}

class Transaction {
  final int? id;
  final TransactionType type;
  final double amount;
  final String description;
  final String? category;
  final DateTime date;
  final int? relatedCustomerId;
  final int? relatedOrderId;
  final String? paymentMethod;
  final DateTime createdAt;

  Transaction({
    this.id,
    required this.type,
    required this.amount,
    required this.description,
    this.category,
    DateTime? date,
    this.relatedCustomerId,
    this.relatedOrderId,
    this.paymentMethod,
    DateTime? createdAt,
  })  : date = date ?? DateTime.now(),
        createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'type': type.index,
      'amount': amount,
      'description': description,
      'category': category,
      'date': date.toIso8601String(),
      'related_customer_id': relatedCustomerId,
      'related_order_id': relatedOrderId,
      'payment_method': paymentMethod,
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory Transaction.fromMap(Map<String, dynamic> map) {
    return Transaction(
      id: map['id'] as int?,
      type: TransactionType.values[map['type'] as int],
      amount: (map['amount'] as num).toDouble(),
      description: map['description'] as String,
      category: map['category'] as String?,
      date: DateTime.parse(map['date'] as String),
      relatedCustomerId: map['related_customer_id'] as int?,
      relatedOrderId: map['related_order_id'] as int?,
      paymentMethod: map['payment_method'] as String?,
      createdAt: DateTime.parse(map['created_at'] as String),
    );
  }
}

extension TransactionTypeExtension on TransactionType {
  String get displayName {
    switch (this) {
      case TransactionType.income:
        return 'Gelir';
      case TransactionType.expense:
        return 'Gider';
    }
  }

  Color get color {
    switch (this) {
      case TransactionType.income:
        return Colors.green;
      case TransactionType.expense:
        return Colors.red;
    }
  }
}
