class AppSettings {
  final int? id;
  final String companyName;
  final String? companyPhone;
  final String? companyAddress;
  final String? whatsappMessageTemplate1;
  final String? whatsappMessageTemplate2;
  final String? whatsappMessageTemplate3;
  final String? whatsappMessageTemplate4;
  final int smsBalance;
  final DateTime? expiryDate;
  final String? securityCode;
  final DateTime updatedAt;

  AppSettings({
    this.id,
    this.companyName = 'MİSPAK ALANYA',
    this.companyPhone,
    this.companyAddress,
    this.whatsappMessageTemplate1 = 'Halılarınız yıkamaya alınmıştır.',
    this.whatsappMessageTemplate2 = 'Halılarınız hazırdır.',
    this.whatsappMessageTemplate3 = 'Yarın teslimat yapılacaktır.',
    this.whatsappMessageTemplate4 = 'Ödemeniz bulunmaktadır.',
    this.smsBalance = 100,
    this.expiryDate,
    this.securityCode,
    DateTime? updatedAt,
  }) : updatedAt = updatedAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'company_name': companyName,
      'company_phone': companyPhone,
      'company_address': companyAddress,
      'whatsapp_template_1': whatsappMessageTemplate1,
      'whatsapp_template_2': whatsappMessageTemplate2,
      'whatsapp_template_3': whatsappMessageTemplate3,
      'whatsapp_template_4': whatsappMessageTemplate4,
      'sms_balance': smsBalance,
      'expiry_date': expiryDate?.toIso8601String(),
      'security_code': securityCode,
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  factory AppSettings.fromMap(Map<String, dynamic> map) {
    return AppSettings(
      id: map['id'] as int?,
      companyName: map['company_name'] as String? ?? 'MİSPAK ALANYA',
      companyPhone: map['company_phone'] as String?,
      companyAddress: map['company_address'] as String?,
      whatsappMessageTemplate1: map['whatsapp_template_1'] as String?,
      whatsappMessageTemplate2: map['whatsapp_template_2'] as String?,
      whatsappMessageTemplate3: map['whatsapp_template_3'] as String?,
      whatsappMessageTemplate4: map['whatsapp_template_4'] as String?,
      smsBalance: map['sms_balance'] as int? ?? 100,
      expiryDate: map['expiry_date'] != null ? DateTime.parse(map['expiry_date'] as String) : null,
      securityCode: map['security_code'] as String?,
      updatedAt: DateTime.parse(map['updated_at'] as String),
    );
  }

  AppSettings copyWith({
    int? id,
    String? companyName,
    String? companyPhone,
    String? companyAddress,
    String? whatsappMessageTemplate1,
    String? whatsappMessageTemplate2,
    String? whatsappMessageTemplate3,
    String? whatsappMessageTemplate4,
    int? smsBalance,
    DateTime? expiryDate,
    String? securityCode,
    DateTime? updatedAt,
  }) {
    return AppSettings(
      id: id ?? this.id,
      companyName: companyName ?? this.companyName,
      companyPhone: companyPhone ?? this.companyPhone,
      companyAddress: companyAddress ?? this.companyAddress,
      whatsappMessageTemplate1: whatsappMessageTemplate1 ?? this.whatsappMessageTemplate1,
      whatsappMessageTemplate2: whatsappMessageTemplate2 ?? this.whatsappMessageTemplate2,
      whatsappMessageTemplate3: whatsappMessageTemplate3 ?? this.whatsappMessageTemplate3,
      whatsappMessageTemplate4: whatsappMessageTemplate4 ?? this.whatsappMessageTemplate4,
      smsBalance: smsBalance ?? this.smsBalance,
      expiryDate: expiryDate ?? this.expiryDate,
      securityCode: securityCode ?? this.securityCode,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}
