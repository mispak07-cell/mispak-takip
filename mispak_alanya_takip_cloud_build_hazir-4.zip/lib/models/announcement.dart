class Announcement {
  final int? id;
  final String title;
  final String description;
  final DateTime date;
  final bool isImportant;
  final DateTime createdAt;

  Announcement({
    this.id,
    required this.title,
    required this.description,
    DateTime? date,
    this.isImportant = false,
    DateTime? createdAt,
  })  : date = date ?? DateTime.now(),
        createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'date': date.toIso8601String(),
      'is_important': isImportant ? 1 : 0,
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory Announcement.fromMap(Map<String, dynamic> map) {
    return Announcement(
      id: map['id'] as int?,
      title: map['title'] as String,
      description: map['description'] as String,
      date: DateTime.parse(map['date'] as String),
      isImportant: (map['is_important'] as int) == 1,
      createdAt: DateTime.parse(map['created_at'] as String),
    );
  }
}
