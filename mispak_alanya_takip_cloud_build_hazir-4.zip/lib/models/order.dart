import 'package:flutter/material.dart';

enum OrderStatus {
  toBePickedUp,
  washing,
  ready,
  toBeDelivered,
  delivered
}

enum ProductType {
  carpet,
  sofa,
  bed,
  curtain,
  blanket,
  quilt,
  carSeat,
  carpetOverlock
}

class Order {
  final int? id;
  final int customerId;
  final String receiptNumber;
  final ProductType productType;
  final int quantity;
  final double? squareMeters;
  final double unitPrice;
  final double totalPrice;
  final OrderStatus status;
  final bool isPaid;
  final double? paidAmount;
  final String? notes;
  final DateTime orderDate;
  final DateTime? deliveryDate;
  final DateTime createdAt;
  final DateTime updatedAt;

  Order({
    this.id,
    required this.customerId,
    required this.receiptNumber,
    required this.productType,
    required this.quantity,
    this.squareMeters,
    required this.unitPrice,
    required this.totalPrice,
    this.status = OrderStatus.toBePickedUp,
    this.isPaid = false,
    this.paidAmount,
    this.notes,
    DateTime? orderDate,
    this.deliveryDate,
    DateTime? createdAt,
    DateTime? updatedAt,
  })  : orderDate = orderDate ?? DateTime.now(),
        createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'customer_id': customerId,
      'receipt_number': receiptNumber,
      'product_type': productType.index,
      'quantity': quantity,
      'square_meters': squareMeters,
      'unit_price': unitPrice,
      'total_price': totalPrice,
      'status': status.index,
      'is_paid': isPaid ? 1 : 0,
      'paid_amount': paidAmount,
      'notes': notes,
      'order_date': orderDate.toIso8601String(),
      'delivery_date': deliveryDate?.toIso8601String(),
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  factory Order.fromMap(Map<String, dynamic> map) {
    return Order(
      id: map['id'] as int?,
      customerId: map['customer_id'] as int,
      receiptNumber: map['receipt_number'] as String,
      productType: ProductType.values[map['product_type'] as int],
      quantity: map['quantity'] as int,
      squareMeters: map['square_meters'] != null ? (map['square_meters'] as num).toDouble() : null,
      unitPrice: (map['unit_price'] as num).toDouble(),
      totalPrice: (map['total_price'] as num).toDouble(),
      status: OrderStatus.values[map['status'] as int],
      isPaid: (map['is_paid'] as int) == 1,
      paidAmount: map['paid_amount'] != null ? (map['paid_amount'] as num).toDouble() : null,
      notes: map['notes'] as String?,
      orderDate: DateTime.parse(map['order_date'] as String),
      deliveryDate: map['delivery_date'] != null ? DateTime.parse(map['delivery_date'] as String) : null,
      createdAt: DateTime.parse(map['created_at'] as String),
      updatedAt: DateTime.parse(map['updated_at'] as String),
    );
  }

  Order copyWith({
    int? id,
    int? customerId,
    String? receiptNumber,
    ProductType? productType,
    int? quantity,
    double? squareMeters,
    double? unitPrice,
    double? totalPrice,
    OrderStatus? status,
    bool? isPaid,
    double? paidAmount,
    String? notes,
    DateTime? orderDate,
    DateTime? deliveryDate,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return Order(
      id: id ?? this.id,
      customerId: customerId ?? this.customerId,
      receiptNumber: receiptNumber ?? this.receiptNumber,
      productType: productType ?? this.productType,
      quantity: quantity ?? this.quantity,
      squareMeters: squareMeters ?? this.squareMeters,
      unitPrice: unitPrice ?? this.unitPrice,
      totalPrice: totalPrice ?? this.totalPrice,
      status: status ?? this.status,
      isPaid: isPaid ?? this.isPaid,
      paidAmount: paidAmount ?? this.paidAmount,
      notes: notes ?? this.notes,
      orderDate: orderDate ?? this.orderDate,
      deliveryDate: deliveryDate ?? this.deliveryDate,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}

extension ProductTypeExtension on ProductType {
  String get displayName {
    switch (this) {
      case ProductType.carpet:
        return 'Halı';
      case ProductType.sofa:
        return 'Koltuk';
      case ProductType.bed:
        return 'Yatak';
      case ProductType.curtain:
        return 'Perde';
      case ProductType.blanket:
        return 'Battaniye';
      case ProductType.quilt:
        return 'Yorgan';
      case ProductType.carSeat:
        return 'Araç Koltuğu';
      case ProductType.carpetOverlock:
        return 'Halı Kenarı Overlok';
    }
  }

  Color get color {
    switch (this) {
      case ProductType.carpet:
        return Colors.teal;
      case ProductType.sofa:
        return Colors.orange;
      case ProductType.bed:
        return Colors.purple;
      case ProductType.curtain:
        return Colors.blue;
      case ProductType.blanket:
        return Colors.green;
      case ProductType.quilt:
        return Colors.pink;
      case ProductType.carSeat:
        return Colors.amber;
      case ProductType.carpetOverlock:
        return Colors.indigo;
    }
  }
}

extension OrderStatusExtension on OrderStatus {
  String get displayName {
    switch (this) {
      case OrderStatus.toBePickedUp:
        return 'Teslim Alınacak';
      case OrderStatus.washing:
        return 'Yıkamada';
      case OrderStatus.ready:
        return 'Hazır';
      case OrderStatus.toBeDelivered:
        return 'Teslim Edilecek';
      case OrderStatus.delivered:
        return 'Teslim Edildi';
    }
  }

  Color get color {
    switch (this) {
      case OrderStatus.toBePickedUp:
        return Colors.orange;
      case OrderStatus.washing:
        return Colors.blue;
      case OrderStatus.ready:
        return Colors.green;
      case OrderStatus.toBeDelivered:
        return Colors.purple;
      case OrderStatus.delivered:
        return Colors.teal;
    }
  }
}
