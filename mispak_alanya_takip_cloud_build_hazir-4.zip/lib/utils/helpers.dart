import 'package:intl/intl.dart';

class Helpers {
  static String formatCurrency(double amount) {
    return NumberFormat.currency(locale: 'tr_TR', symbol: '₺', decimalDigits: 2).format(amount);
  }

  static String formatDate(DateTime date) {
    return DateFormat('dd.MM.yyyy', 'tr_TR').format(date);
  }

  static String formatDateTime(DateTime date) {
    return DateFormat('dd.MM.yyyy HH:mm', 'tr_TR').format(date);
  }
}
