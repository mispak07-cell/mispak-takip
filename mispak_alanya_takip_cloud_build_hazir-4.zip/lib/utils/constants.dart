class AppConstants {
  static const String appName = 'MİSPAK ALANYA TAKİP';
  static const String appVersion = '1.0.0';
  static const String companyName = 'MİSPAK ALANYA';

  static const List<String> whatsappTemplates = [
    'Halılarınız yıkamaya alınmıştır',
    'Halılarınız hazırdır',
    'Yarın teslimat yapılacaktır',
    'Ödemeniz bulunmaktadır',
  ];

  static const Map<String, String> productTypes = {
    'carpet': 'Halı',
    'sofa': 'Koltuk',
    'bed': 'Yatak',
    'curtain': 'Perde',
    'blanket': 'Battaniye',
    'quilt': 'Yorgan',
    'car_seat': 'Araç Koltuğu',
    'carpet_overlock': 'Halı Kenarı Overlok',
  };
}
