import '../models/order.dart';
import '../models/customer.dart';
import 'database_service.dart';

class ReportService {
  final DatabaseService _db = DatabaseService();

  Future<Map<String, dynamic>> generateDailyReport(DateTime date) async {
    final transactions = await _db.getTransactionsByDate(date);
    final dailyTotals = await _db.getDailyTotals(date);

    return {
      'newOrders': 0,
      'deliveredOrders': 0,
      'income': dailyTotals['income'],
      'expense': dailyTotals['expense'],
      'balance': dailyTotals['balance'],
    };
  }

  Future<List<Customer>> getDebtors() async {
    final customers = await _db.getAllCustomers();
    return customers.where((c) => c.debt > 0).toList()
      ..sort((a, b) => b.debt.compareTo(a.debt));
  }

  Future<Map<String, int>> getOrderDistributionByStatus() async {
    final orders = await _db.getAllOrders();
    final distribution = <String, int>{};

    for (final status in OrderStatus.values) {
      distribution[status.displayName] = orders.where((o) => o.status == status).length;
    }

    return distribution;
  }

  Future<double> getTotalRevenue() async {
    final orders = await _db.getAllOrders();
    return orders.fold(0.0, (sum, o) => sum + o.totalPrice);
  }
}
