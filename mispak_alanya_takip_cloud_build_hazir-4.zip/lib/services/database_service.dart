import 'dart:io';

import 'package:flutter/services.dart' show rootBundle;
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import '../models/announcement.dart';
import '../models/app_settings.dart';
import '../models/customer.dart';
import '../models/order.dart';
import '../models/transaction.dart';

class DatabaseService {
  static final DatabaseService _instance = DatabaseService._internal();
  static Database? _database;

  factory DatabaseService() => _instance;
  DatabaseService._internal();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'mispak_alanya_takip.db');

    await _copySeedDatabaseIfNeeded(path);

    return openDatabase(
      path,
      version: 2,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
    );
  }

  Future<void> _copySeedDatabaseIfNeeded(String path) async {
    final dbFile = File(path);
    if (await dbFile.exists()) return;

    await Directory(dirname(path)).create(recursive: true);
    final data = await rootBundle.load('assets/database/mispak_seed.db');
    final bytes = data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
    await dbFile.writeAsBytes(bytes, flush: true);
  }

  Future<void> _onCreate(Database db, int version) async {
    await _createCustomersTable(db);
    await _createOrdersTable(db);
    await _createTransactionsTable(db);
    await _createAnnouncementsTable(db);
    await _createAppSettingsTable(db);
    await _seedDefaultSettings(db);
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    await _createCustomersTable(db);
    await _createOrdersTable(db);
    await _createTransactionsTable(db);
    await _createAnnouncementsTable(db);
    await _createAppSettingsTable(db);
    await _seedDefaultSettings(db);
  }

  Future<void> _createCustomersTable(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_number TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        phone TEXT NOT NULL,
        phone2 TEXT,
        address TEXT NOT NULL,
        neighborhood TEXT,
        debt REAL DEFAULT 0.0,
        notes TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    ''');
  }

  Future<void> _createOrdersTable(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER NOT NULL,
        receipt_number TEXT UNIQUE NOT NULL,
        product_type INTEGER NOT NULL,
        quantity INTEGER NOT NULL,
        square_meters REAL,
        unit_price REAL NOT NULL,
        total_price REAL NOT NULL,
        status INTEGER NOT NULL DEFAULT 0,
        is_paid INTEGER NOT NULL DEFAULT 0,
        paid_amount REAL,
        notes TEXT,
        order_date TEXT NOT NULL,
        delivery_date TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE
      )
    ''');
  }

  Future<void> _createTransactionsTable(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        type INTEGER NOT NULL,
        amount REAL NOT NULL,
        description TEXT NOT NULL,
        category TEXT,
        date TEXT NOT NULL,
        related_customer_id INTEGER,
        related_order_id INTEGER,
        payment_method TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY (related_customer_id) REFERENCES customers(id) ON DELETE SET NULL,
        FOREIGN KEY (related_order_id) REFERENCES orders(id) ON DELETE SET NULL
      )
    ''');
  }

  Future<void> _createAnnouncementsTable(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS announcements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        date TEXT NOT NULL,
        is_important INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL
      )
    ''');
  }

  Future<void> _createAppSettingsTable(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS app_settings (
        id INTEGER PRIMARY KEY,
        company_name TEXT NOT NULL,
        company_phone TEXT,
        company_address TEXT,
        whatsapp_template_1 TEXT,
        whatsapp_template_2 TEXT,
        whatsapp_template_3 TEXT,
        whatsapp_template_4 TEXT,
        sms_balance INTEGER NOT NULL DEFAULT 100,
        expiry_date TEXT,
        security_code TEXT,
        updated_at TEXT NOT NULL
      )
    ''');
  }

  Future<void> _seedDefaultSettings(Database db) async {
    await db.insert(
      'app_settings',
      AppSettings(id: 1).toMap(),
      conflictAlgorithm: ConflictAlgorithm.ignore,
    );
  }

  Future<int> insertCustomer(Customer customer) async {
    final db = await database;
    return db.insert('customers', customer.toMap());
  }

  Future<List<Customer>> getAllCustomers() async {
    final db = await database;
    final maps = await db.query('customers', orderBy: 'name COLLATE NOCASE ASC');
    return List.generate(maps.length, (i) => Customer.fromMap(maps[i]));
  }

  Future<String> generateCustomerNumber() async {
    final db = await database;
    final result = await db.rawQuery('SELECT COUNT(*) AS count FROM customers');
    final count = ((result.first['count'] as num?)?.toInt() ?? 0) + 1;
    return 'MIS${count.toString().padLeft(4, '0')}';
  }

  Future<int> insertOrder(Order order) async {
    final db = await database;
    return db.insert('orders', order.toMap());
  }

  Future<List<Order>> getAllOrders() async {
    final db = await database;
    final maps = await db.query('orders', orderBy: 'order_date DESC');
    return List.generate(maps.length, (i) => Order.fromMap(maps[i]));
  }

  Future<String> generateReceiptNumber() async {
    final db = await database;
    final result = await db.rawQuery('SELECT COUNT(*) AS count FROM orders');
    final count = ((result.first['count'] as num?)?.toInt() ?? 0) + 1;
    final now = DateTime.now();
    return 'F${now.year}${now.month.toString().padLeft(2, '0')}${count.toString().padLeft(4, '0')}';
  }

  Future<int> insertTransaction(Transaction transaction) async {
    final db = await database;
    return db.insert('transactions', transaction.toMap());
  }

  Future<List<Transaction>> getTransactionsByDate(DateTime date) async {
    final db = await database;
    final startOfDay = DateTime(date.year, date.month, date.day);
    final endOfDay = startOfDay.add(const Duration(days: 1));
    final maps = await db.query(
      'transactions',
      where: 'date >= ? AND date < ?',
      whereArgs: [startOfDay.toIso8601String(), endOfDay.toIso8601String()],
      orderBy: 'date DESC',
    );
    return List.generate(maps.length, (i) => Transaction.fromMap(maps[i]));
  }

  Future<Map<String, double>> getDailyTotals(DateTime date) async {
    final db = await database;
    final startOfDay = DateTime(date.year, date.month, date.day);
    final endOfDay = startOfDay.add(const Duration(days: 1));

    final incomeResult = await db.rawQuery(
      'SELECT SUM(amount) AS total FROM transactions WHERE type = ? AND date >= ? AND date < ?',
      [TransactionType.income.index, startOfDay.toIso8601String(), endOfDay.toIso8601String()],
    );

    final expenseResult = await db.rawQuery(
      'SELECT SUM(amount) AS total FROM transactions WHERE type = ? AND date >= ? AND date < ?',
      [TransactionType.expense.index, startOfDay.toIso8601String(), endOfDay.toIso8601String()],
    );

    final income = (incomeResult.first['total'] as num?)?.toDouble() ?? 0.0;
    final expense = (expenseResult.first['total'] as num?)?.toDouble() ?? 0.0;

    return {
      'income': income,
      'expense': expense,
      'balance': income - expense,
    };
  }

  Future<List<Announcement>> getAllAnnouncements() async {
    final db = await database;
    final maps = await db.query('announcements', orderBy: 'date DESC');
    return List.generate(maps.length, (i) => Announcement.fromMap(maps[i]));
  }

  Future<AppSettings?> getSettings() async {
    final db = await database;
    final maps = await db.query('app_settings', where: 'id = ?', whereArgs: [1], limit: 1);
    if (maps.isEmpty) return null;
    return AppSettings.fromMap(maps.first);
  }
}
