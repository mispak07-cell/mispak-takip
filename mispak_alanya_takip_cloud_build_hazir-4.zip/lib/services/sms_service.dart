import 'package:url_launcher/url_launcher.dart';
import '../models/customer.dart';

class SMSService {
  static Future<void> sendSMS(String phoneNumber, {String? message}) async {
    final String url = message != null
        ? 'sms:' + phoneNumber + '?body=' + Uri.encodeComponent(message)
        : 'sms:' + phoneNumber;

    final Uri uri = Uri.parse(url);

    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    } else {
      throw 'SMS acilamadi';
    }
  }

  static Future<void> makePhoneCall(String phoneNumber) async {
    final String url = 'tel:' + phoneNumber;
    final Uri uri = Uri.parse(url);

    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    } else {
      throw 'Arama yapilamadi';
    }
  }

  static Future<void> sendTemplateSMS(Customer customer, int templateNumber) async {
    String message = '';

    switch (templateNumber) {
      case 1:
        message = 'Sayin ' + customer.name + ', halilariniz yikamaya alinmistir. MISPak ALANYA';
        break;
      case 2:
        message = 'Sayin ' + customer.name + ', halilariniz hazirdir. MISPak ALANYA';
        break;
      case 3:
        message = 'Sayin ' + customer.name + ', yarin teslimat yapilacaktir. MISPak ALANYA';
        break;
      case 4:
        message = 'Sayin ' + customer.name + ', odemeniz bulunmaktadir. MISPak ALANYA';
        break;
    }

    await sendSMS(customer.phone, message: message);
  }
}
