import 'package:url_launcher/url_launcher.dart';
import '../models/customer.dart';

class WhatsAppService {
  static Future<void> openWhatsApp(String phoneNumber, {String? message}) async {
    String cleanNumber = phoneNumber.replaceAll(RegExp(r'[^0-9]'), '');

    if (!cleanNumber.startsWith('90') && cleanNumber.length == 10) {
      cleanNumber = '90' + cleanNumber;
    } else if (!cleanNumber.startsWith('90') && cleanNumber.length == 11 && cleanNumber.startsWith('0')) {
      cleanNumber = '90' + cleanNumber.substring(1);
    }

    final String url = message != null
        ? 'https://wa.me/' + cleanNumber + '?text=' + Uri.encodeComponent(message)
        : 'https://wa.me/' + cleanNumber;

    final Uri uri = Uri.parse(url);

    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      throw 'WhatsApp acilamadi';
    }
  }

  static Future<void> sendTemplateMessage(Customer customer, int templateNumber) async {
    String message = '';

    switch (templateNumber) {
      case 1:
        message = 'Sayin ' + customer.name + ', halilariniz yikamaya alinmistir. MİSPAK ALANYA';
        break;
      case 2:
        message = 'Sayin ' + customer.name + ', halilariniz hazirdir. MİSPAK ALANYA';
        break;
      case 3:
        message = 'Sayin ' + customer.name + ', yarin teslimat yapilacaktir. MİSPAK ALANYA';
        break;
      case 4:
        message = 'Sayin ' + customer.name + ', odemeniz bulunmaktadir. MİSPAK ALANYA';
        break;
    }

    await openWhatsApp(customer.phone, message: message);
  }
}
